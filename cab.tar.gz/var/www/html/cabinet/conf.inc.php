<?php

$config['domain']='b63.sip64.ru';
$config['ip']='91.196.6.51';

?>